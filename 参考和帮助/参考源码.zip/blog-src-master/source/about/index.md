title: About
date: 2014-07-17 11:03:29
comment: true
---

小鶸一枚，除了 Java 和 Python，其他语言都没生产环境经验的代码渣

封印全栈技能树，重新点数据库与云数据库服务平台技能树中

业余生活逃不出写代码、[读书、看动漫、看电影](/favorite/)这几件事，偶尔写点博客

综上所述，一条单身狗


+ E-mail: [panjiabang@gmail.com](mailto:panjiabang@gmail.com)
+ Github: [@JamesPan](https://github.com/JamesPan)
+ Weibo : [@潘小鶸](http://weibo.com/panjiabang)

