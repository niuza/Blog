title: Pastime
date: 2015-10-26 11:03:29
comment: true
---

也许你听说过，「业余时间决定人生」；也许你还听说过，「听过很多道理，依然过不好这一生」。书籍、代码、博客、运动、电影、动漫、美剧，这就是我的业余生活。

> 我的能力就这么多。我若全心工作，则必然忽略生活；我若用心生活，则必然一事无成；我若两者兼顾，又难免平庸

显然，我绝不可能是一个现充。

{% stream %}
<!-- {% figure  []() %} -->
{% figure http://ww1.sinaimg.cn/bmiddle/006tKfTcgw1f6kfy1q61mj30bw0go0vy.jpg [盗墓笔记](https://movie.douban.com/subject/24827387/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f6kfv68tglj208x0bi74r.jpg [Linux内核设计与实现](https://book.douban.com/subject/6097773/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/72f96cbagw1f6bw13cbjqj20by0gon0t.jpg [绝地逃亡](https://movie.douban.com/subject/24529353/) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/72f96cbagw1f6bvywcdz7j20b30gowhc.jpg [心慌方](https://movie.douban.com/subject/1305903/) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f63777xz6aj20900bcjro.jpg [软技能](https://book.douban.com/subject/26835090/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f5w6iwghwkj208c0c9jrw.jpg [一条狗](https://book.douban.com/subject/26760591/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f5v2mln4gnj2076095t8z.jpg [精准拉伸](https://book.douban.com/subject/26818259/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefjw1f5uwknz937j20bs0gotbo.jpg [这个美术部有问题！](https://movie.douban.com/subject/26655965/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f5w6pvohlrj20br0goad4.jpg [心迷宫](https://movie.douban.com/subject/25917973/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f5s2bbzau8j20bn0godjd.jpg [寒战](https://movie.douban.com/subject/6890730/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f5p6htfhsdj20bs0gotcn.jpg [寒战2](https://movie.douban.com/subject/20505982/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f5okvr06qej20c90gotbp.jpg [食戟之灵 贰之皿](https://movie.douban.com/subject/26688568/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f5n0lin8tmj20b40gon1f.jpg [大鱼海棠](https://movie.douban.com/subject/5045678/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f5h0i5casaj20a30a6wem.jpg [正义女神不睁眼](https://book.douban.com/subject/26689753/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f5h0fwu5l4j20b90goacu.jpg [蝙蝠侠大战超人：正义黎明](https://movie.douban.com/subject/24750534/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f5ff53bp4ij20bu0goaf5.jpg [树大招风](https://movie.douban.com/subject/26265170/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f57xv4uf6kj208i0c3aaq.jpg [设计原本](https://book.douban.com/subject/5406042/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f56s89vheoj20b40gotca.jpg [惊天魔盗团2](https://movie.douban.com/subject/25662337/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f54kjvd884j21871qqnpe.jpg [Person of Interest](https://movie.douban.com/subject/26387813/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefjw1f4zzh3kdzcj20ao0go786.jpg [危机13小时](https://movie.douban.com/subject/26220717/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f4z8iw25hhj21aw1xg4qp.jpg [王牌贱谍：格林斯比](https://movie.douban.com/subject/25830732/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f4rr12jj17j208c0c9gm7.jpg [从Paxos到Zookeeper](https://book.douban.com/subject/26292004/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f4rnbrv9b0j21e01tkdqz.jpg [情趣体验师](https://movie.douban.com/subject/26700845/) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f4p2ghbllmj20pa0zkwim.jpg [魔兽](https://movie.douban.com/subject/2131940/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f4n69hwr5hj208i0c3jrh.jpg [重新定义公司](https://book.douban.com/subject/26582822/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f4blztee8wj208r0brmxd.jpg [松本行弘的程序世界](https://book.douban.com/subject/6756090/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f4blxq9ozvj21kw27gkjm.jpg [我是证人](https://movie.douban.com/subject/26313973/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f46yrbg9gkj20jg0rjgou.jpg [空之境界](https://movie.douban.com/subject/2354897/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f44koxkhdhj20e10l2q50.jpg [大学之路](https://book.douban.com/subject/26584286/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f446u0h4dqj208i0c3q36.jpg [思考的乐趣](https://book.douban.com/subject/10779597/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f438udl1f5j212b1kw7jo.jpg [狩猎](https://movie.douban.com/subject/6985810/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f42ii6k24mj21kw27m4qq.jpg [白日焰火](https://movie.douban.com/subject/21941804/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f42dlhuqseg205007iaaj.gif [Open by Design](http://www.oreilly.com/programming/free/open-by-design.csp) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f3z7ypgbccj208f0c6t8x.jpg [有限与无限的游戏](https://book.douban.com/subject/25742296/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3xo6poow0j208r0brq38.jpg [让云落地：云计算服务模式](https://book.douban.com/subject/26709066/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f3we5x4o6kj21kw27nhdt.jpg [幻体：续命游戏](https://movie.douban.com/subject/24325815/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f3w5blhlowj208u0bldgp.jpg [数据之巅](https://book.douban.com/subject/25871778/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3w5f7vj2ej20om0yhq97.jpg [一念天堂](https://movie.douban.com/subject/26611801/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3vcdl8kp7j21k92bcnpd.jpg [硅谷 第三季](https://movie.douban.com/subject/26366492/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f3uqa4r8zyj20b00go783.jpg [火锅英雄](https://movie.douban.com/subject/25662327/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3t4dz3yzjj208r0bo74n.jpg [你好哇，程序员](https://book.douban.com/subject/26772838/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f3ry2ccl5ej208r0br3yw.jpg [文明之光 （第三册）](https://book.douban.com/subject/26275177/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3p2pxdxl8g205007iq35.gif [How to Make Mistakes in Python](http://www.oreilly.com/programming/free/how-to-make-mistakes-in-python.csp) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3o2tcra82j208r0brwev.jpg [Open Stack设计与实现](https://book.douban.com/subject/26374647/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3n4j3tlhvj20fk0m80w7.jpg [Re：从零开始的异世界生活](https://movie.douban.com/subject/26575153/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3lx4cxzecj208c0c9mxh.jpg [番茄工作法图解](https://book.douban.com/subject/5916234/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f3ks84ezv4j208f0c60t0.jpg [程序员的呐喊](https://book.douban.com/subject/25884108/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f3hif1ghkoj208c0c9t8t.jpg [精进](https://book.douban.com/subject/26761696/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3h5oegeo9j20xc1ddtfa.jpg [猫鼠游戏](https://movie.douban.com/subject/1305487/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f3evz5toprj20tu15oq8p.jpg [北京遇上西雅图之不二情书](https://movie.douban.com/subject/26322792/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3eo5mspl3j20rs13bn8i.jpg [踏血寻梅](https://movie.douban.com/subject/25966085/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f3bmaliiwog205007it93.gif [Software Architecture Patterns](http://www.oreilly.com/programming/free/software-architecture-patterns.csp) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f38655c19gj21kw27g4qq.jpg [美人鱼](https://movie.douban.com/subject/19944106/) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f37vbkfennj208c0c90t6.jpg [一个定理的诞生](https://book.douban.com/subject/26681315/) %} 
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f37vagkcczj20h30o6tca.jpg [垫底辣妹](https://movie.douban.com/subject/26259677/) %} 
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f342g692x5j21kw2bthdt.jpg [一夜惊喜](https://movie.douban.com/subject/16475702/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f32xwuzrs5j20te15o77z.jpg [龙虾](https://movie.douban.com/subject/20514947/) %} 
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f2z2sju03mj20b40gomy4.jpg [驯服烂代码](https://book.douban.com/subject/26208707/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f2yuf9i3nhj208o0bu0su.jpg [只是为了好玩](https://book.douban.com/subject/25930025/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f2xqpnu26qj20go0nwwlx.jpg [线上游戏的老婆不可能是女生](https://movie.douban.com/subject/26588672/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f2wntwi5omj21kw299b2a.jpg [希特勒回来了](https://movie.douban.com/subject/26585014/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f2wnse02orj20900bct8z.jpg [七周七并发模型](https://book.douban.com/subject/26337939/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f2rysuk2rxj208u0blt8w.jpg [Docker源码分析](https://book.douban.com/subject/26581184/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f2rmo7cqmej21kw27nqv5.jpg [伦敦陷落](https://movie.douban.com/subject/25757186/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f2rmpge1n2j20rg12wjvh.jpg [在下坂本，有何贵干？](https://movie.douban.com/subject/26708698/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f2pr5mhpvmj208i0c3gm1.jpg [DOOM启世录（纪念版）](https://book.douban.com/subject/26642310/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f2jd4x3eh5j205z08dt90.jpg [听爸爸的话！](https://movie.douban.com/subject/10569609/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f2i92m4srhj20su15otir.jpg [我的特工爷爷](https://movie.douban.com/subject/25945280/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f28cepm5koj212y1jke0e.jpg [荒野猎人](https://movie.douban.com/subject/5327268/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f2784xw3p6j208i0c33z7.jpg [图灵的秘密](http://book.douban.com/subject/10779604/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f21h2rlzxvj21kw295x6p.jpg [倭寇的踪迹](https://movie.douban.com/subject/6425116/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f21df7vsiuj21kw299kjl.jpg [箭士柳白猿](https://movie.douban.com/subject/7564989/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f1s6zqo3a4j213e1jp168.jpg [疯狂动物城](https://movie.douban.com/subject/25662329/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f1s6x5xs9bj21kw27gqv5.jpg [谍影特工](https://movie.douban.com/subject/10792320/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f1nbnm9339j21jk26ku0x.jpg [叶问3](https://movie.douban.com/subject/11598977/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f1hsev4ex4j21bl1ww1kx.jpg [数学女孩](https://book.douban.com/subject/26677354/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f1f9l931ldj21bn1xgb29.jpg [死侍](http://movie.douban.com/subject/3718279/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f1auv3fnd0j21kw2957wh.jpg [卧虎藏龙：青冥宝剑](http://movie.douban.com/subject/21327512/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f0zcla6r77j20il0rs11j.jpg [高跟鞋先生](http://movie.douban.com/subject/26652816/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f0hs7grqjvj20dc0hsta9.jpg [股权是什么](https://www.zhihu.com/publications/hour/19550544) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f0bqlp5gw8j21hc276e81.jpg [美丽心灵](http://movie.douban.com/subject/1306029/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f09t74z3omj21jk27e1kz.jpg [真相禁区](https://movie.douban.com/subject/26348798/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1f02kottgbmj21kw2gsb29.jpg [大空头](http://movie.douban.com/subject/26303622/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1ezwm063a12j21kw2964qr.jpg [后会无期](http://movie.douban.com/subject/25805741/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f0hs4h28yrj208c0ccgm1.jpg [经济学通识](http://book.douban.com/subject/3869949/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1eza2r0qms9j20xc1ake81.jpg [万万没想到](http://movie.douban.com/subject/26320029/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ez5dt3qyt9j21kw27g7wh.jpg [寻龙诀](http://movie.douban.com/subject/3077412/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f0j5qf1934j20xc1e94qp.jpg [火星救援](http://movie.douban.com/subject/25864085/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1eyxg0noaz4j20rs12wkc8.jpg [师父](http://movie.douban.com/subject/25919910/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1eyxg31oat8j208l0c0t8n.jpg [MacTalk 跨越边界](http://book.douban.com/subject/26663519/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1eyxg9a7uz5j20rs15tgr9.jpg [走出帝制:从晚清到民国的历史回望](http://www.amazon.cn/dp/B016OHU51Q/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ey11kb76xxj210v1jkno1.jpg [007：幽灵党](http://movie.douban.com/subject/11620560/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1exu11vywgoj20go0nkn8u.jpg [我被绑架到贵族女校当庶民样本](http://movie.douban.com/subject/25919935/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1exswud7onwj20hs0outcf.jpg [安德的游戏](http://movie.douban.com/subject/5323957/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1exloglk815j20mk0xc0vt.jpg [大独裁者](http://movie.douban.com/subject/1295646/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ex98ycf4kaj21kw27ne83.jpg [刺客聂隐娘](http://movie.douban.com/subject/2303845/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ewsibsiv3wj21k92bc4qp.jpg [白日梦想家](http://movie.douban.com/subject/2133323/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ewsf6xl0qcj20900bc74s.jpg [30岁的保健体育](https://movie.douban.com/subject/5308296/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1ewrv6mkqmuj20dw0fnju6.jpg [这个男人来自地球](http://movie.douban.com/subject/2300586/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ewpsmz6o3cj21kw27cu0y.jpg [解救吾先生](http://movie.douban.com/subject/25798448/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ewpsli9y18j21kw27nqv5.jpg [夏洛特烦恼](http://movie.douban.com/subject/25964071/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1ewn7u9xph3j21ip20wqv6.jpg [十二公民](http://movie.douban.com/subject/24875534/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ew6fnfb64kj21d81wr7ot.jpg [煎饼侠](http://movie.douban.com/subject/25895276/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1evry7hqws4j21kw2cbb2a.jpg [星际穿越](http://movie.douban.com/subject/1889243/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1evry28qvdkj21kw28g4qq.jpg [终结者：创世纪](http://movie.douban.com/subject/3338862/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1evrxwqr5b8j21d81wwkjl.jpg [模仿游戏](https://movie.douban.com/subject/10463953/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1evrxld7ewoj20640940t2.jpg [Java并发编程的艺术](http://book.douban.com/subject/26591326/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1evp49flrehj208u0blwem.jpg [像外行一样思考，像专家一样实践（修订版）](http://book.douban.com/subject/26340523/) %}
{% figure http://ww2.sinaimg.cn/large/e724cbefgw1evohugdozxj20p70zutoi.jpg [杀破狼2](http://movie.douban.com/subject/23788440/) %}
{% figure http://ww4.sinaimg.cn/large/e724cbefgw1ewlgz4jemlj208l0c0weo.jpg [暗时间](https://book.douban.com/subject/6709809/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1evohyl6lgpj20fk0m8jud.jpg [干物妹！小埋](http://movie.douban.com/subject/26282460/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1eve8m4id43j20fx0m8q8e.jpg [滚蛋吧！肿瘤君](https://movie.douban.com/subject/26289144/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1eusta4105oj20zk1gdno0.jpg [道士下山](http://movie.douban.com/subject/24879839/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1eu0vzvyrpyj21kw27ge81.jpg [少年班](http://movie.douban.com/subject/26219652/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1eu0e5wydkmj21kw2ca4cr.jpg [美国狙击手](http://movie.douban.com/subject/21263666/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1eu086toz28j20jg0t441u.jpg [博学无术](http://movie.douban.com/subject/6855109/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyol37r0vj20f30hsacy.jpg [我老婆是学生会长！](http://movie.douban.com/subject/26282457/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyova5gmyj20gy0nywht.jpg [食戟之灵](http://movie.douban.com/subject/26219198/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1etyu4om7myj20930b9dg6.jpg [深入剖析Tomcat](http://book.douban.com/subject/10426640/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1etyst9xf3ej208f0c674i.jpg [若为自由故](http://book.douban.com/subject/26314527/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etyu7x8r4cj208o0bujrs.jpg [断舍离](http://book.douban.com/subject/24749465/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etyuy5ujybj20zk1go45w.jpg [硅谷 第二季](http://movie.douban.com/subject/25871679/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyrybmu3oj208r0br3yy.jpg [程序员必读的职业规划书](http://book.douban.com/subject/26383703/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyrbvwhpcj210l1hcqm9.jpg [军中乐园](http://movie.douban.com/subject/20515070/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyudphl3oj21kw28ge81.jpg [机械姬](http://movie.douban.com/subject/4160540/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1etyoydsabtj21kw28fx6p.jpg [Who Am I](http://movie.douban.com/subject/25932086/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etyopxfi2hj20b40f5n17.jpg [樱花庄的宠物女孩](http://movie.douban.com/subject/10581328/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyt2mslrej20nm0xcgzi.jpg [路人女主的养成方法](http://movie.douban.com/subject/25850625/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1etyubjb3yqj21kw26sb2a.jpg [万物生长](http://movie.douban.com/subject/25872931/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1etysx4c4n8j208u0bldfz.jpg [创业维艰](http://book.douban.com/subject/26306686/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etysw29vc3j208i0c0jrl.jpg [从0到1](http://book.douban.com/subject/26297606/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etysv2eabtj208l0bxaa5.jpg [构建之法](http://book.douban.com/subject/25965995/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1ettka7vtavj20hs0p5gum.jpg [月刊少女野崎君](http://movie.douban.com/subject/25850705/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etytoxcdaoj20930b974i.jpg [Getting Started with Google Guava](http://book.douban.com/subject/25710862/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1ettk1rwd0rj20dw0jnac4.jpg [漫画家与助手们](http://movie.douban.com/subject/25785220/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1etyrrgmvlyj21ii28i1kx.jpg [互联网之子](http://movie.douban.com/subject/25785114/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etytk2s5xzj20a30a374f.jpg [金钱有术](http://book.douban.com/subject/26237302/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f2wnwr1kxej208l0c0gls.jpg [重来](https://book.douban.com/subject/5320866/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1etyquwbgosj21kw2dwu0y.jpg [绣春刀](http://movie.douban.com/subject/24745500/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1etytngy6xgj20a30a3t91.jpg [创业时我们在知乎聊什么](http://book.douban.com/subject/25800616/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1etyot1u02dj20ir0rsdhk.jpg [硅谷 第一季](http://movie.douban.com/subject/20644938/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ettjxkk8bbj20nl0xcqr1.jpg [游戏人生](http://movie.douban.com/subject/24883272/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1ettjv8s6w4j20hs0nddia.jpg [CSI](http://movie.douban.com/subject/1310172/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ettjqe29zsj218n1ske7e.jpg [中二病也要谈恋爱](http://movie.douban.com/subject/11226092/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1ettjn7l3o9j20b80g8q3s.jpg [高效程序的奥秘](http://book.douban.com/subject/1159177/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1ettji4fnq5j208i0c074r.jpg [黑客与画家](http://book.douban.com/subject/6021440/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ettjfmsldrj20tr15on71.jpg [Prison Break](http://movie.douban.com/subject/1419297/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etyt08pz2vj20bc0g40tt.jpg [计算机程序的构造和解释](http://book.douban.com/subject/1148282/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1ettjdrokdpj20cj0hedhr.jpg [魔法禁书目录](http://movie.douban.com/subject/3251306/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etysyd54u9j207s0b4aac.jpg [编程之道](http://book.douban.com/subject/1899158/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1ettjb8kgt1j20b40fjjsi.jpg [某科学的超电磁炮](http://movie.douban.com/subject/4067827/) %}
{% figure http://ww1.sinaimg.cn/bmiddle/e724cbefgw1etyrvt8ckzj20bc0g474w.jpg [人月神话](http://book.douban.com/subject/1102259/) %}
{% figure http://ww3.sinaimg.cn/bmiddle/e724cbefgw1f2xv8pnr23j208l0c0dgh.jpg [数学之美](https://book.douban.com/subject/10750155/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f2rm3f9kqsj20ao0dc3zd.jpg [编程之美](https://book.douban.com/subject/3004255/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1f2xv3ks9z0j208f0c6q38.jpg [拖拉一点也无妨](https://book.douban.com/subject/24839553/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f2xv5a120uj208f0c6aa9.jpg [淘宝技术这十年](https://book.douban.com/subject/24335672/) %}
{% figure http://ww4.sinaimg.cn/bmiddle/e724cbefgw1etyrug9t1lj208c0apq38.jpg [代码大全](http://book.douban.com/subject/1477390/) %}
{% endstream %}

---

基础设施与相关技术：

+ [jQuery](https://jquery.com)
+ [jQuery Lazy Load](https://plugins.jquery.com/lazyload/)
+ [BootCDN](http://www.bootcdn.cn)
+ [Plugins | Hexo](http://hexo.io/docs/plugins.html)
+ [做一个照片流，分享你喜欢的书和电影](/2016/01/28/show-your-favorites-collection-in-hexo/)


<script type="text/javascript">
$(function() {
  var shown = 18;
  $('figure').slice(shown).addClass('foldable');
  if ($('.foldable').length > 0) {
    $('.foldable').hide();
    $('div.hexo-img-stream').after('<p id="btn-more" class="article-more-link" align="center"><a href="javascript:;">Show More</a></p>');
    $('#btn-more').click(function() {
      $('.foldable').show();
      $('#btn-more').hide();
    });
  }
});
</script>

