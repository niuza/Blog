title: Exchange
date: 2016-04-10 15:18:29
comment: true
---

这里展示的是我手上已经看完了的而且不打算收藏的实体书。如果你手上有我想看的书，那么正好，我们可以做个交换，或许还可以交个朋友。当然，运费到付。

如果你手上闲置的书籍不在我的「心愿单」中，但你觉得我或许会感兴趣，也可以商量。

如果我们在三次元中已经是朋友，尽管开口便是，直接赠送。话虽如此，我更希望你能有书籍和我交换，毕竟友谊的基础是平等交流而不是单向索取。

请在评论区留言交流。

{% stream %}
<!-- {% figure  []() %} -->
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f58tdhrqmbj208o0bu74l.jpg [Objective-C 程序设计](https://book.douban.com/subject/19967897/) %}
{% figure http://ww2.sinaimg.cn/bmiddle/e724cbefgw1f5h0i5casaj20a30a6wem.jpg [正义女神不睁眼](https://book.douban.com/subject/26689753/) %}

{% endstream %}

## 心愿单

{% stream %}
<!-- {% figure  []() %} -->
{% endstream %}

