title: Bullshit
meta: false
comments: false
static-disqus: true
---


[Disqus 都支持哪些 HTML 标签呢？][1]可以用 `<br>` 换行，用 `<p>` 分段，用 `<a>` 写超链接，用 `<blockquote>` 引用别人的话，用 `<s>` 加删除线，`<u>` 加下划线，`<strong>` 加粗，还可以用 `<pre><code>` 给代码加上高亮特技！

点击[这里][2]订阅我的扯淡~

<div id="disqus_thread">
  吭哧吭哧加载中…网速感人
  <noscript>Please enable JavaScript to view the <a href="//disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
</div>

<script type="text/javascript">
  var disqus_shortname = 'jamespan';
  var disqus_identifier = '/nonsense/index.html';
  var disqus_title = 'Nonsense';
  var disqus_url = 'http://blog.jamespan.me/nonsense/index.html';
  (function() {
    var dsq = document.createElement('script');
    dsq.type = 'text/javascript';
    dsq.async = true;
    dsq.src = '//a.disquscdn.com/embed.js';
    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
  })();
</script>

<script type="text/javascript">
  $(function(){
    $(".article-footer").remove();
  });
</script>

[1]: https://help.disqus.com/customer/portal/articles/466253-what-html-tags-are-allowed-within-comments-
[2]: https://jamespan.disqus.com/nonsense/latest.rss
