title: Timeline
#date: 2015-01-08 01:07:30
fontawsome: true
comment: true
---

{% mood 2015-10-27 01:12:57 fa-sitemap %}
成功使用 Travis CI 实现博客自动化部署，从此不用被拘束在一台电脑上了，开启移动编辑的新时代~
{% endmood %}

{% mood 2015-10-25 13:34:44 fa-sitemap %}
墙内部署从 Gitcafe 变成 CNPaaS 了，Upstream 摆脱了单点困扰，哈哈~
{% endmood %}

{% mood 2015-10-25 10:33:50 fa-sitemap %}
博客部署改造遭遇 Gitcafe 抽风，从 VIP 到 Upstream 全部单点，我的心好痛
{% endmood %}

{% mood 2015-10-03 11:32:39 fa-weixin %}
微信公众号有了第一个订阅者，是博客的老读者，感动哭了
{% endmood %}

{% mood 2015-06-18 21:56:58 fa-weixin %}
#单身狗の日常# 大学时候就不熟的女神突然主动联系你加微信，通常没好事
{% endmood %}

{% mood 2015-04-19 23:31:01 fa-book %}
#单身狗の日常# 在咖啡馆吃晚餐，然后把《[创业维艰](http://book.douban.com/subject/26306686/)》看完了
{% endmood %}

{% mood 2015-04-19 12:01:33 fa-cogs %}
把博客的时间线的实现方式换了，直接使用 Hexo 来生成，自己写了一个 Hexo Tag 解析器
{% endmood %}

{% mood 2015-03-28 17:32:59 fa-film %}
[#路人女主的养成方法#](http://www.bilibili.com/sp/路人女主的养成方法) 路人女主完结了，暂时没有新番可看了，拙计
{% endmood %}

{% mood 2015-01-24 23:55:21 fa-book %}
搞到了找了好久的《人本界面》，万能的淘宝！
{% endmood %}

{% mood 2015-01-23 18:38:26 fa-code %}
地址收缩算法！
{% endmood %}

{% mood 2015-01-21 12:15:44 fa-code-fork %}
总算把洗数据代码的性能提升了好多好多，几次重写，太不容易
{% endmood %}

{% mood 2015-01-19 12:41:27 fa-laptop %}
最近喜欢上了前端技术，感觉新世界的大门打开了
{% endmood %}

{% mood 2015-01-19 03:14:39 fa-coffee %}
如何才能恢复早睡早起…
{% endmood %}

{% mood 2015-01-19 01:39:07 fa-film %}
<a href="http://tv.sohu.com/20150114/n407782242.shtml">#Person of Interest S04E12#</a> Agent Shaw 还活着！肯定是演员档期冲突没法拍某几集，然后就拍成这样子
{% endmood %}

{% mood 2015-01-18 14:21:07 fa-code %}
修改了一下 Timestamp 里面包含时间戳的容器，然后写了一篇文章
{% endmood %}

{% mood 2015-01-15 04:23:25 fa-code %}
复制到剪贴板是个大难题，只能通过点击时全选来减少操作，没法自动复制
{% endmood %}

{% mood 2015-01-15 01:02:06 fa-code %}
时间戳轻应用完成，保存到主屏幕的效果超赞
{% endmood %}

{% mood 2015-01-14 21:37:41 fa-code %}
我说我要写一个 iOS 应用专门算时间戳，@不周跟我说可以写一个轻应用放博客上，通过浏览器书签访问
{% endmood %}

{% mood 2015-01-13 13:32:04 fa-slideshare %}
成功把 <a href="http://lab.hakim.se/reveal-js/">reveal.js</a> 集成到<a href="/2015/01/13/presentation-with-revealjs/" target="_blank">博客</a>了，不知道怎么做特效的时候可以看 <a href="/slides/index.html" target="_blank">demo</a>
{% endmood %}

{% mood 2015-01-11 22:54:30 fa-code-fork %}
尝试不用 iframe 来加载 Timeline 页面的努力以失败告终，一翻折腾之后学会了<a href="/2015/01/12/redirect-with-js/" target="_blank">用 js 控制浏览器跳转页面</a>，然后给博客弄了 <a href="https://github.com/sergiolepore/hexo-tag-emojis">Emoji 插件</a>，也不算白忙活😊
{% endmood %}

{% mood 2015-01-10 01:34:45 fa-code-fork %}
一写代码就根本停不下来
{% endmood %}

{% mood 2015-01-08 23:50:10 fa-dashboard %}
以为线上机器 HSF 线程池满，原来是虚惊一场
{% endmood %}

{% mood 2015-01-08 02:58:13 fa-warning %}
总算把这个时间轴折腾好了，可是又到半夜才睡觉，唉
{% endmood %}

{% mood 2015-01-08 02:45:51 fa-film %}
<a href="http://tv.sohu.com/20150107/n407604754.shtml">#Person of Interest S04E11#</a> Agent Shaw 跪了，我的心好痛
{% endmood %}

---

鸣谢：

+ [Font Awesome Icons](http://fortawesome.github.io/Font-Awesome/icons/)
+ [BootCDN](http://www.bootcdn.cn)
+ [Emoji cheat sheet](http://www.emoji-cheat-sheet.com)
+ [Plugins | Hexo](http://hexo.io/docs/plugins.html)
